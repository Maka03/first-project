import './App.css';
import Category from './components/Category/Category';
import Product from './components/Product/Product';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to my first React app!</h1>
        <p>
        This is a react component!
        </p>
      </header>
      <Category title='Electronics'/>
      <Category title='Electronics'/>
    </div>
  );
}

export default App;
