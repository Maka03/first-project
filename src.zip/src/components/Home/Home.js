import React,{useState} from 'react'
import './Home.css'
function Home() {
  return (
    <div><div>Home</div>
    <p>count: {count}</p>
    <button onClick={()=>setcount(count+1)}>
        INCREASE COUNTER
    </button>
    </div>
  )
}

export default Home