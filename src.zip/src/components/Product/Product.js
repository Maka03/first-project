import React from 'react'
import './Product.css'
import {NavLink} from 'react-router-dom'
function Product(props) {
  return (
    <div classname='product'>
      <span>{props.firstname}</span>
      Product</div>
  )
}

export default Product