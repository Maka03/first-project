import React from 'react'
import Product from '../Product/Product'
import './Category'

function Category() {
  return (
    <div><h2>Category</h2>
    <div className='catcontainer'>
    <Product />
    <Product />
    <Product />
    </div>
    </div>
  )
}

export default Category